import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import User from "./src/models/User.js"; // adjust if needed

dotenv.config();

const users = [
  {
    name: "Admin User",
    email: "admin@example.com",
    rawPassword: "admin123", // store temporarily
    role: "admin",
  },
  {
    name: "Student User",
    email: "student@example.com",
    rawPassword: "student123",
    role: "student",
  },
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected");

    // Clear old data
    await User.deleteMany();

    // Hash passwords & insert into passwordHash field
    const hashedUsers = await Promise.all(
      users.map(async (user) => ({
        name: user.name,
        email: user.email,
        role: user.role,
        passwordHash: await bcrypt.hash(user.rawPassword, 10),
      }))
    );

    await User.insertMany(hashedUsers);

    console.log("✅ Seed data inserted!");
    process.exit();
  } catch (err) {
    console.error("❌ Error seeding data:", err);
    process.exit(1);
  }
}

seed();
