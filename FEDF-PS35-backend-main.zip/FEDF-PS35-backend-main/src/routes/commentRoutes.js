import express from "express";
import { authMiddleware } from "../middleware/auth.js";
import Comment from "../models/Comment.js";
import Notification from "../models/Notification.js";
import User from "../models/User.js";

const router = express.Router();

// Create comment
router.post("/", authMiddleware, async (req, res) => {
  try {
    const { content, relatedTo, mentions, parentComment } = req.body;

    const comment = await Comment.create({
      content,
      author: req.user.id,
      relatedTo,
      mentions: mentions || [],
      parentComment,
    });

    // If reply, add to parent's replies
    if (parentComment) {
      await Comment.findByIdAndUpdate(parentComment, {
        $push: { replies: comment._id },
      });
    }

    // Notify mentioned users
    if (mentions && mentions.length > 0) {
      for (const userId of mentions) {
        await Notification.create({
          userId,
          type: "mention",
          title: "You were mentioned",
          message: `You were mentioned in a comment`,
          relatedTo: { model: relatedTo.model, id: relatedTo.id },
        });
      }
    }

    const populatedComment = await Comment.findById(comment._id).populate(
      "author",
      "name email"
    );

    res.status(201).json(populatedComment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get comments
router.get("/", authMiddleware, async (req, res) => {
  try {
    const { relatedModel, relatedId } = req.query;

    let filter = {};
    if (relatedModel && relatedId) {
      filter["relatedTo.model"] = relatedModel;
      filter["relatedTo.id"] = relatedId;
      filter.parentComment = null; // Only top-level comments
    }

    const comments = await Comment.find(filter)
      .populate("author", "name email")
      .populate({
        path: "replies",
        populate: { path: "author", select: "name email" },
      })
      .sort({ createdAt: -1 });

    res.json(comments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update comment
router.put("/:id", authMiddleware, async (req, res) => {
  try {
    const { content } = req.body;
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" });
    }

    if (comment.author.toString() !== req.user.id) {
      return res
        .status(403)
        .json({ message: "You can only edit your own comments" });
    }

    comment.content = content;
    comment.edited = true;
    comment.editedAt = new Date();
    await comment.save();

    res.json(comment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete comment
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" });
    }

    if (
      comment.author.toString() !== req.user.id &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Delete all replies
    await Comment.deleteMany({ parentComment: req.params.id });

    await Comment.findByIdAndDelete(req.params.id);

    res.json({ message: "Comment deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
