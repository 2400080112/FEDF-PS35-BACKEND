import express from "express";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import ActivityLog from "../models/ActivityLog.js";

const router = express.Router();

// Get activity logs
router.get("/", authMiddleware, async (req, res) => {
  try {
    const { relatedModel, relatedId, userId } = req.query;

    let filter = {};

    if (relatedModel && relatedId) {
      filter["relatedTo.model"] = relatedModel;
      filter["relatedTo.id"] = relatedId;
    }

    if (userId) {
      filter.userId = userId;
    }

    // Students can only see their own logs
    if (req.user.role !== "admin") {
      filter.userId = req.user.id;
    }

    const logs = await ActivityLog.find(filter)
      .populate("userId", "name email")
      .sort({ createdAt: -1 })
      .limit(100);

    res.json(logs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get activity summary
router.get(
  "/summary",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const { startDate, endDate } = req.query;

      let matchFilter = {};
      if (startDate || endDate) {
        matchFilter.createdAt = {};
        if (startDate) matchFilter.createdAt.$gte = new Date(startDate);
        if (endDate) matchFilter.createdAt.$lte = new Date(endDate);
      }

      const summary = await ActivityLog.aggregate([
        { $match: matchFilter },
        {
          $group: {
            _id: "$action",
            count: { $sum: 1 },
          },
        },
        { $sort: { count: -1 } },
      ]);

      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

export default router;
