import express from "express";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import Group from "../models/Group.js";
import User from "../models/User.js";
import ActivityLog from "../models/ActivityLog.js";

const router = express.Router();

// Create group (Admin only)
router.post("/", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { name, description, members, projectId } = req.body;

    // Validate members exist
    const memberIds = members.map((m) => m.userId);
    const users = await User.find({ _id: { $in: memberIds } });

    if (users.length !== memberIds.length) {
      return res.status(400).json({ message: "Some members not found" });
    }

    const group = await Group.create({
      name,
      description,
      members,
      projectId,
      createdBy: req.user.id,
    });

    // Log activity
    await ActivityLog.create({
      userId: req.user.id,
      action: "group-created",
      description: `Created group "${name}"`,
      relatedTo: { model: "Group", id: group._id },
    });

    res.status(201).json(group);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all groups
router.get("/", authMiddleware, async (req, res) => {
  try {
    let groups;

    if (req.user.role === "admin") {
      groups = await Group.find()
        .populate("members.userId", "name email")
        .populate("projectId", "title")
        .populate("createdBy", "name email")
        .sort({ createdAt: -1 });
    } else {
      // Students see only their groups
      groups = await Group.find({ "members.userId": req.user.id })
        .populate("members.userId", "name email")
        .populate("projectId", "title")
        .sort({ createdAt: -1 });
    }

    res.json(groups);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get single group
router.get("/:id", authMiddleware, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id)
      .populate("members.userId", "name email role")
      .populate("projectId")
      .populate("createdBy", "name email");

    if (!group) {
      return res.status(404).json({ message: "Group not found" });
    }

    // Check access
    const isMember = group.members.some(
      (m) => m.userId._id.toString() === req.user.id
    );
    if (req.user.role !== "admin" && !isMember) {
      return res.status(403).json({ message: "Access denied" });
    }

    res.json(group);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update group
router.put("/:id", authMiddleware, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);

    if (!group) {
      return res.status(404).json({ message: "Group not found" });
    }

    // Check permission
    const isLeader = group.members.some(
      (m) => m.userId.toString() === req.user.id && m.role === "leader"
    );

    if (req.user.role !== "admin" && !isLeader) {
      return res
        .status(403)
        .json({ message: "Only admin or group leader can update" });
    }

    Object.keys(req.body).forEach((key) => {
      group[key] = req.body[key];
    });

    await group.save();

    res.json(group);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Add member to group
router.post(
  "/:id/members",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const { userId, role = "member" } = req.body;
      const group = await Group.findById(req.params.id);

      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }

      // Check if already a member
      const isMember = group.members.some(
        (m) => m.userId.toString() === userId
      );
      if (isMember) {
        return res.status(400).json({ message: "User already in group" });
      }

      group.members.push({ userId, role });
      await group.save();

      res.json(group);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
);

// Remove member from group
router.delete(
  "/:id/members/:userId",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const group = await Group.findById(req.params.id);

      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }

      group.members = group.members.filter(
        (m) => m.userId.toString() !== req.params.userId
      );

      await group.save();

      res.json(group);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
);

// Delete group
router.delete(
  "/:id",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const group = await Group.findByIdAndDelete(req.params.id);

      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }

      res.json({ message: "Group deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

export default router;
