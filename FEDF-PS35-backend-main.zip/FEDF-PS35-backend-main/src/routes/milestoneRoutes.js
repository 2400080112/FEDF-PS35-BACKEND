import express from "express";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import Milestone from "../models/Milestone.js";
import ActivityLog from "../models/ActivityLog.js";

const router = express.Router();

// Create milestone
router.post("/", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { title, description, projectId, dueDate } = req.body;

    const milestone = await Milestone.create({
      title,
      description,
      projectId,
      dueDate,
      createdBy: req.user.id,
    });

    await ActivityLog.create({
      userId: req.user.id,
      action: "milestone-created",
      description: `Created milestone "${title}"`,
      relatedTo: { model: "Milestone", id: milestone._id },
    });

    res.status(201).json(milestone);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get milestones
router.get("/", authMiddleware, async (req, res) => {
  try {
    const { projectId } = req.query;

    let filter = {};
    if (projectId) filter.projectId = projectId;

    const milestones = await Milestone.find(filter)
      .populate("projectId", "title")
      .populate("tasks")
      .sort({ dueDate: 1 });

    res.json(milestones);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get single milestone
router.get("/:id", authMiddleware, async (req, res) => {
  try {
    const milestone = await Milestone.findById(req.params.id)
      .populate("projectId")
      .populate("tasks");

    if (!milestone) {
      return res.status(404).json({ message: "Milestone not found" });
    }

    res.json(milestone);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update milestone
router.put("/:id", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const milestone = await Milestone.findById(req.params.id);

    if (!milestone) {
      return res.status(404).json({ message: "Milestone not found" });
    }

    Object.keys(req.body).forEach((key) => {
      milestone[key] = req.body[key];
    });

    await milestone.save();

    res.json(milestone);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update milestone status
router.patch("/:id/status", authMiddleware, async (req, res) => {
  try {
    const { status } = req.body;
    const milestone = await Milestone.findById(req.params.id);

    if (!milestone) {
      return res.status(404).json({ message: "Milestone not found" });
    }

    milestone.status = status;

    if (status === "completed") {
      milestone.completedAt = new Date();
    }

    await milestone.save();

    res.json(milestone);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete milestone
router.delete(
  "/:id",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const milestone = await Milestone.findByIdAndDelete(req.params.id);

      if (!milestone) {
        return res.status(404).json({ message: "Milestone not found" });
      }

      res.json({ message: "Milestone deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

export default router;
