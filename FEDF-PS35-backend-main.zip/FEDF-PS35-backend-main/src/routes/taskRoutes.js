import express from "express";
import { authMiddleware } from "../middleware/auth.js";
import Task from "../models/Task.js";
import Group from "../models/Group.js";
import Notification from "../models/Notification.js";
import ActivityLog from "../models/ActivityLog.js";

const router = express.Router();

// Create task
router.post("/", authMiddleware, async (req, res) => {
  try {
    const {
      title,
      description,
      projectId,
      groupId,
      assignedTo,
      priority,
      deadline,
    } = req.body;

    // Check if user has permission (admin or group leader)
    if (req.user.role !== "admin" && groupId) {
      const group = await Group.findById(groupId);
      const isLeader = group.members.some(
        (m) => m.userId.toString() === req.user.id && m.role === "leader"
      );

      if (!isLeader) {
        return res
          .status(403)
          .json({ message: "Only group leader can create tasks" });
      }
    }

    const task = await Task.create({
      title,
      description,
      projectId,
      groupId,
      assignedTo,
      priority: priority || "medium",
      deadline,
      createdBy: req.user.id,
    });

    // Create notification for assigned user
    if (assignedTo) {
      await Notification.create({
        userId: assignedTo,
        type: "task-assigned",
        title: "New Task Assigned",
        message: `You have been assigned task: ${title}`,
        relatedTo: { model: "Task", id: task._id },
      });
    }

    // Log activity
    await ActivityLog.create({
      userId: req.user.id,
      action: "task-created",
      description: `Created task "${title}"`,
      relatedTo: { model: "Task", id: task._id },
    });

    res.status(201).json(task);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all tasks
router.get("/", authMiddleware, async (req, res) => {
  try {
    const { projectId, groupId, status, assignedTo } = req.query;

    let filter = {};

    if (projectId) filter.projectId = projectId;
    if (groupId) filter.groupId = groupId;
    if (status) filter.status = status;
    if (assignedTo) filter.assignedTo = assignedTo;

    // Students see only their tasks or group tasks
    if (req.user.role !== "admin") {
      const userGroups = await Group.find({ "members.userId": req.user.id });
      const groupIds = userGroups.map((g) => g._id);

      filter.$or = [
        { assignedTo: req.user.id },
        { groupId: { $in: groupIds } },
      ];
    }

    const tasks = await Task.find(filter)
      .populate("assignedTo", "name email")
      .populate("createdBy", "name email")
      .populate("projectId", "title")
      .populate("groupId", "name")
      .sort({ createdAt: -1 });

    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get single task
router.get("/:id", authMiddleware, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id)
      .populate("assignedTo", "name email")
      .populate("createdBy", "name email")
      .populate("projectId")
      .populate("groupId")
      .populate("comments.userId", "name email");

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    res.json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update task
router.put("/:id", authMiddleware, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Check permission
    const canEdit =
      req.user.role === "admin" ||
      task.createdBy.toString() === req.user.id ||
      task.assignedTo?.toString() === req.user.id;

    if (!canEdit) {
      return res.status(403).json({ message: "Access denied" });
    }

    Object.keys(req.body).forEach((key) => {
      task[key] = req.body[key];
    });

    await task.save();

    // Log activity
    await ActivityLog.create({
      userId: req.user.id,
      action: "task-updated",
      description: `Updated task "${task.title}"`,
      relatedTo: { model: "Task", id: task._id },
    });

    res.json(task);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update task status
router.patch("/:id/status", authMiddleware, async (req, res) => {
  try {
    const { status } = req.body;
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    task.status = status;
    await task.save();

    // Notify on completion
    if (status === "completed" && task.createdBy.toString() !== req.user.id) {
      await Notification.create({
        userId: task.createdBy,
        type: "task-completed",
        title: "Task Completed",
        message: `Task "${task.title}" has been marked as completed`,
        relatedTo: { model: "Task", id: task._id },
      });
    }

    res.json(task);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Add comment to task
router.post("/:id/comments", authMiddleware, async (req, res) => {
  try {
    const { text } = req.body;
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    task.comments.push({
      userId: req.user.id,
      text,
    });

    await task.save();

    res.json(task);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete task
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Only creator or admin can delete
    if (
      req.user.role !== "admin" &&
      task.createdBy.toString() !== req.user.id
    ) {
      return res.status(403).json({ message: "Access denied" });
    }

    await Task.findByIdAndDelete(req.params.id);

    res.json({ message: "Task deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
