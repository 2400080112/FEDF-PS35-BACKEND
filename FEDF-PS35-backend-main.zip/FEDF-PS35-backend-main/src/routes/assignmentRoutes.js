import express from "express";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import Project from "../models/Project.js";
import Assignment from "../models/Assignment.js";

const router = express.Router();

// Assign project to student (Admin only)
router.post(
  "/assign",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const { projectId, studentId } = req.body;

      // Check if project exists
      const project = await Project.findById(projectId);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Check if already assigned
      const existingAssignment = await Assignment.findOne({
        projectId,
        studentId,
      });

      if (existingAssignment) {
        return res
          .status(400)
          .json({ message: "Project already assigned to this student" });
      }

      // Create assignment
      const assignment = await Assignment.create({
        projectId,
        studentId,
        assignedBy: req.user.id,
        assignedAt: new Date(),
        status: "pending", // pending, in-progress, submitted, completed
      });

      res.status(201).json(assignment);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
);

// Get all assignments (Admin sees all, Student sees only theirs)
router.get("/", authMiddleware, async (req, res) => {
  try {
    let assignments;

    if (req.user.role === "admin") {
      assignments = await Assignment.find()
        .populate("projectId")
        .populate("studentId", "name email");
    } else {
      // Students only see their own assignments
      assignments = await Assignment.find({ studentId: req.user.id }).populate(
        "projectId"
      );
    }

    res.json(assignments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get assignments for a specific project (Admin only)
router.get(
  "/project/:projectId",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const assignments = await Assignment.find({
        projectId: req.params.projectId,
      }).populate("studentId", "name email");
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

// Update assignment status
router.patch("/:id/status", authMiddleware, async (req, res) => {
  try {
    const { status } = req.body;
    const assignment = await Assignment.findById(req.params.id);

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" });
    }

    // Students can only update their own assignments
    if (
      req.user.role !== "admin" &&
      assignment.studentId.toString() !== req.user.id
    ) {
      return res.status(403).json({ message: "Access denied" });
    }

    assignment.status = status;
    await assignment.save();

    res.json(assignment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete assignment (Admin only)
router.delete(
  "/:id",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const assignment = await Assignment.findByIdAndDelete(req.params.id);
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      res.json({ message: "Assignment removed" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

export default router;
