// routes/analytics.js
import express from "express";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import Project from "../models/Project.js";
import Group from "../models/Group.js";
import Task from "../models/Task.js";
import Submission from "../models/Submission.js";
import User from "../models/User.js";

const router = express.Router();

// Get admin dashboard statistics
router.get(
  "/admin/dashboard",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const stats = {
        totalProjects: await Project.countDocuments(),
        activeProjects: await Project.countDocuments({ status: "active" }),
        totalGroups: await Group.countDocuments(),
        activeGroups: await Group.countDocuments({ status: "active" }),
        totalStudents: await User.countDocuments({ role: "student" }),
        totalTasks: await Task.countDocuments(),
        completedTasks: await Task.countDocuments({ status: "completed" }),
        pendingSubmissions: await Submission.countDocuments({
          status: "submitted",
        }),
        gradedSubmissions: await Submission.countDocuments({
          status: "approved",
        }),
      };

      // Project status breakdown
      const projectsByStatus = await Project.aggregate([
        {
          $group: {
            _id: "$status",
            count: { $sum: 1 },
          },
        },
      ]);

      // Task status breakdown
      const tasksByStatus = await Task.aggregate([
        {
          $group: {
            _id: "$status",
            count: { $sum: 1 },
          },
        },
      ]);

      // Recent activities
      const recentProjects = await Project.find()
        .populate("createdBy", "name")
        .sort({ createdAt: -1 })
        .limit(5);

      const recentSubmissions = await Submission.find()
        .populate("groupId", "name")
        .populate("projectId", "title")
        .sort({ submittedAt: -1 })
        .limit(5);

      res.json({
        stats,
        projectsByStatus,
        tasksByStatus,
        recentProjects,
        recentSubmissions,
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

// Get student dashboard statistics
router.get("/student/dashboard", authMiddleware, async (req, res) => {
  try {
    // Get user's groups
    const userGroups = await Group.find({ "members.userId": req.user.id });
    const groupIds = userGroups.map((g) => g._id);

    const stats = {
      myGroups: userGroups.length,
      assignedTasks: await Task.countDocuments({ assignedTo: req.user.id }),
      completedTasks: await Task.countDocuments({
        assignedTo: req.user.id,
        status: "completed",
      }),
      pendingTasks: await Task.countDocuments({
        assignedTo: req.user.id,
        status: { $in: ["todo", "in-progress"] },
      }),
      groupProjects: await Project.countDocuments({
        _id: { $in: userGroups.map((g) => g.projectId) },
      }),
    };

    // My tasks
    const myTasks = await Task.find({ assignedTo: req.user.id })
      .populate("projectId", "title")
      .sort({ deadline: 1 })
      .limit(5);

    // Group submissions
    const groupSubmissions = await Submission.find({
      groupId: { $in: groupIds },
    })
      .populate("projectId", "title")
      .populate("groupId", "name")
      .sort({ submittedAt: -1 })
      .limit(5);

    res.json({
      stats,
      myTasks,
      groupSubmissions,
      myGroups: userGroups,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get project analytics
router.get("/project/:id", authMiddleware, async (req, res) => {
  try {
    const projectId = req.params.id;

    const stats = {
      totalTasks: await Task.countDocuments({ projectId }),
      completedTasks: await Task.countDocuments({
        projectId,
        status: "completed",
      }),
      totalGroups: await Group.countDocuments({ projectId }),
      submissions: await Submission.countDocuments({ projectId }),
      gradedSubmissions: await Submission.countDocuments({
        projectId,
        status: "approved",
      }),
    };

    // Task breakdown
    const tasksByStatus = await Task.aggregate([
      { $match: { projectId: mongoose.Types.ObjectId(projectId) } },
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 },
        },
      },
    ]);

    // Task breakdown by priority
    const tasksByPriority = await Task.aggregate([
      { $match: { projectId: mongoose.Types.ObjectId(projectId) } },
      {
        $group: {
          _id: "$priority",
          count: { $sum: 1 },
        },
      },
    ]);

    // Group performance
    const groups = await Group.find({ projectId }).populate(
      "members.userId",
      "name"
    );

    res.json({
      stats,
      tasksByStatus,
      tasksByPriority,
      groups,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get group analytics
router.get("/group/:id", authMiddleware, async (req, res) => {
  try {
    const groupId = req.params.id;

    const group = await Group.findById(groupId)
      .populate("members.userId", "name email")
      .populate("projectId");

    if (!group) {
      return res.status(404).json({ message: "Group not found" });
    }

    const stats = {
      totalTasks: await Task.countDocuments({ groupId }),
      completedTasks: await Task.countDocuments({
        groupId,
        status: "completed",
      }),
      totalSubmissions: await Submission.countDocuments({ groupId }),
      latestGrade: null,
    };

    // Get latest graded submission
    const latestSubmission = await Submission.findOne({
      groupId,
      status: "approved",
    }).sort({ reviewedAt: -1 });

    if (latestSubmission && latestSubmission.grade) {
      stats.latestGrade = latestSubmission.grade;
    }

    // Member contributions
    const memberContributions = await Promise.all(
      group.members.map(async (member) => {
        const tasksCompleted = await Task.countDocuments({
          groupId,
          assignedTo: member.userId._id,
          status: "completed",
        });

        const totalTasks = await Task.countDocuments({
          groupId,
          assignedTo: member.userId._id,
        });

        return {
          user: member.userId,
          role: member.role,
          tasksCompleted,
          totalTasks,
          completionRate:
            totalTasks > 0 ? (tasksCompleted / totalTasks) * 100 : 0,
        };
      })
    );

    res.json({
      group,
      stats,
      memberContributions,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
