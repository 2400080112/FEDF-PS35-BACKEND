// routes/projects.js
import express from "express";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import Project from "../models/Project.js";
import Assignment from "../models/Assignment.js"; // Add this import

const router = express.Router();

// Get all projects
router.get("/", authMiddleware, async (req, res) => {
  try {
    let projects;

    if (req.user.role === "admin") {
      projects = await Project.find()
        .populate("createdBy", "name email")
        .sort({ createdAt: -1 });
    } else {
      projects = await Project.find().sort({ createdAt: -1 });
    }

    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get single project by ID
router.get("/:id", authMiddleware, async (req, res) => {
  try {
    const project = await Project.findById(req.params.id).populate(
      "createdBy",
      "name email"
    );

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    res.json(project);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create project (Admin only)
router.post("/", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const project = await Project.create({
      ...req.body,
      createdBy: req.user.id,
    });
    res.status(201).json(project);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update project (Admin only)
router.put("/:id", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    // Update fields
    Object.keys(req.body).forEach((key) => {
      project[key] = req.body[key];
    });

    await project.save();

    res.json(project);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete project (Admin only)
router.delete(
  "/:id",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const project = await Project.findById(req.params.id);

      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Delete all assignments associated with this project first
      await Assignment.deleteMany({ projectId: req.params.id });

      // Delete the project
      await Project.findByIdAndDelete(req.params.id);

      res.json({
        message: "Project and associated assignments deleted successfully",
      });
    } catch (error) {
      console.error("Delete project error:", error); // Add logging
      res.status(500).json({ message: error.message });
    }
  }
);

export default router;
