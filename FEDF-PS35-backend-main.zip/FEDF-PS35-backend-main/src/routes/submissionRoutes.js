import express from "express";
import multer from "multer";
import path from "path";
import { authMiddleware, requireRole } from "../middleware/auth.js";
import Submission from "../models/Submission.js";
import Notification from "../models/Notification.js";
import ActivityLog from "../models/ActivityLog.js";

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/submissions/");
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    // Allow common file types
    const allowedTypes =
      /pdf|doc|docx|zip|rar|png|jpg|jpeg|txt|ppt|pptx|xls|xlsx/;
    const extname = allowedTypes.test(
      path.extname(file.originalname).toLowerCase()
    );
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error("Invalid file type"));
  },
});

// Create/upload submission
router.post(
  "/",
  authMiddleware,
  upload.array("files", 10),
  async (req, res) => {
    try {
      const { projectId, groupId, description } = req.body;

      // Check if user is in the group
      const group = await Group.findById(groupId);
      const isMember = group.members.some(
        (m) => m.userId.toString() === req.user.id
      );

      if (!isMember) {
        return res
          .status(403)
          .json({ message: "You are not a member of this group" });
      }

      // Get latest version
      const latestSubmission = await Submission.findOne({
        projectId,
        groupId,
      }).sort({ version: -1 });
      const version = latestSubmission ? latestSubmission.version + 1 : 1;

      const files = req.files.map((file) => ({
        filename: file.filename,
        originalName: file.originalname,
        url: `/uploads/submissions/${file.filename}`,
        size: file.size,
        mimeType: file.mimetype,
      }));

      const submission = await Submission.create({
        projectId,
        groupId,
        submittedBy: req.user.id,
        files,
        description,
        version,
        status: "submitted",
        submittedAt: new Date(),
      });

      // Notify admin
      await Notification.create({
        userId: group.createdBy, // Assuming admin created the group
        type: "submission-received",
        title: "New Submission",
        message: `Group "${group.name}" submitted their project`,
        relatedTo: { model: "Submission", id: submission._id },
      });

      await ActivityLog.create({
        userId: req.user.id,
        action: "submission-uploaded",
        description: `Uploaded submission (v${version})`,
        relatedTo: { model: "Submission", id: submission._id },
      });

      res.status(201).json(submission);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
);

// Get submissions
router.get("/", authMiddleware, async (req, res) => {
  try {
    const { projectId, groupId } = req.query;

    let filter = {};
    if (projectId) filter.projectId = projectId;
    if (groupId) filter.groupId = groupId;

    // Students see only their group's submissions
    if (req.user.role !== "admin") {
      const userGroups = await Group.find({ "members.userId": req.user.id });
      const groupIds = userGroups.map((g) => g._id);
      filter.groupId = { $in: groupIds };
    }

    const submissions = await Submission.find(filter)
      .populate("projectId", "title")
      .populate("groupId", "name")
      .populate("submittedBy", "name email")
      .populate("reviewedBy", "name email")
      .sort({ submittedAt: -1 });

    res.json(submissions);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get single submission
router.get("/:id", authMiddleware, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id)
      .populate("projectId")
      .populate("groupId")
      .populate("submittedBy", "name email")
      .populate("reviewedBy", "name email");

    if (!submission) {
      return res.status(404).json({ message: "Submission not found" });
    }

    res.json(submission);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Grade submission (Admin only)
router.post(
  "/:id/grade",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const { score, maxScore, breakdown, feedback, status } = req.body;

      const submission = await Submission.findById(req.params.id);

      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }

      submission.grade = {
        score,
        maxScore,
        breakdown: breakdown || [],
      };
      submission.feedback = feedback;
      submission.status = status || "approved";
      submission.reviewedBy = req.user.id;
      submission.reviewedAt = new Date();

      await submission.save();

      // Notify all group members
      const group = await Group.findById(submission.groupId);
      for (const member of group.members) {
        await Notification.create({
          userId: member.userId,
          type: "submission-graded",
          title: "Submission Graded",
          message: `Your submission has been graded. Score: ${score}/${maxScore}`,
          relatedTo: { model: "Submission", id: submission._id },
        });
      }

      await ActivityLog.create({
        userId: req.user.id,
        action: "submission-graded",
        description: `Graded submission - Score: ${score}/${maxScore}`,
        relatedTo: { model: "Submission", id: submission._id },
      });

      res.json(submission);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
);

// Update submission status
router.patch(
  "/:id/status",
  authMiddleware,
  requireRole("admin"),
  async (req, res) => {
    try {
      const { status, feedback } = req.body;

      const submission = await Submission.findById(req.params.id);

      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }

      submission.status = status;
      if (feedback) submission.feedback = feedback;
      submission.reviewedBy = req.user.id;
      submission.reviewedAt = new Date();

      await submission.save();

      res.json(submission);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
);

// Delete submission
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id);

    if (!submission) {
      return res.status(404).json({ message: "Submission not found" });
    }

    // Only group members or admin can delete
    const group = await Group.findById(submission.groupId);
    const isMember = group.members.some(
      (m) => m.userId.toString() === req.user.id
    );

    if (req.user.role !== "admin" && !isMember) {
      return res.status(403).json({ message: "Access denied" });
    }

    await Submission.findByIdAndDelete(req.params.id);

    res.json({ message: "Submission deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
