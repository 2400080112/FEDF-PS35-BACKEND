import mongoose from "mongoose";

const submissionSchema = new mongoose.Schema(
  {
    projectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
      required: true,
    },
    groupId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Group",
      required: true,
    },
    submittedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    files: [
      {
        filename: String,
        originalName: String,
        url: String,
        size: Number,
        mimeType: String,
        uploadedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    description: String,
    version: {
      type: Number,
      default: 1,
    },
    status: {
      type: String,
      enum: [
        "draft",
        "submitted",
        "under-review",
        "approved",
        "rejected",
        "resubmit",
      ],
      default: "draft",
    },
    submittedAt: Date,
    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    reviewedAt: Date,
    feedback: String,
    grade: {
      score: Number,
      maxScore: Number,
      breakdown: [
        {
          criteria: String,
          score: Number,
          maxScore: Number,
          comments: String,
        },
      ],
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("Submission", submissionSchema);
